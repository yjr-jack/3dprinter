void print(char gm[],char fs[],char x[],char y[],char z[],char e[]){
    char fi[];
    int a;
    float gm1,fs1,x1,y1,z1,e1;
    for(a=0;g[a]!='\0';a++){
        fi[a]=g[a+1];
    }
    
}