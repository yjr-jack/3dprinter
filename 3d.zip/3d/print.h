#include <stdio.h>
#include <stdlib.h>
void print(char g[],char f[],char x[],char y[],char z[],char e[]);