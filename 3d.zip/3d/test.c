#include <stdio.h>
#include <stdlib.h>
void main(){
    char a[50];
    int b='3.123';
    printf("%d",b);
}