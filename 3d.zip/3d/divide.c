void get(){
    FILE *fp;
    char str[100];
    int a;
    char b[50];
    if( (fp=fopen("/var/mobile/Containers/Data/Application/4FF6791B-136C-4F0E-AD2F-0AF648E44C8A/Documents/KeepData/script/3d/3d2.txt","rt")) == NULL ){
        puts("Fail to open file!");
        exit(1);
    }
   
    while(fgets(str, 99, fp) != NULL){
        if(str[0]!='\n'&&str[0]!=';'str[0]!='\0'){
            divide(str);
        }
    }
    fclose(fp);
}

void divide(char str[]){
    int a,b;
    int c=0;
    char str2[50]="\0",str3[20]="\0";
    char gm[20],fs[20];
    char x[20],y[20],z[20],e[20];
    
    for(a=0;(str[a]!='\n'&&str[a]!=';'&&str[a]!='\0');a++){
        str2[a]=str[a];
    }
    for(a=0;a<50;a++){
        if(str2[a]!=' '&&str2[a]!='\0'){
            str3[c]=str2[a];
            c++;
        }else{//c=' '/'0'
            str3[c]='\0';
            switch(str3[0]){
            case 71://G
            case 77://M
                strcpy(gm,str3);
                break;
            case 83://S
            case 70://F
                for(b=0;str3[b]!='\0';b++){
                    fs[b]=str3[b+1];
                }
                break;
            case 88://X
                for(b=0;str3[b]!='\0';b++){
                    x[b]=str3[b+1];
                }
                break;
            case 89://Y
                for(b=0;str3[b]!='\0';b++){
                    y[b]=str3[b+1];
                }
                break;
            case 90://Z
                for(b=0;str3[b]!='\0';b++){
                    z[b]=str3[b+1];
                }
                break;
            case 69://E
                for(b=0;str3[b]!='\0';b++){
                    e[b]=str3[b+1];
                }
                break;
            }
            if(str2[a]=='\0'||str2[a+1]=='\0'){
                print(gm,fs,x,y,z,e);
                break;
            }
            c=0;
        }
    }
}