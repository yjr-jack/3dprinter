#include <stdio.h>
#include <stdlib.h>
#include "print.h"
void get();
void divide(char str[]);