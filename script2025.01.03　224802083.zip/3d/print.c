void print(char gm[],char fs[],char x[],char y[],char z[],char e[]){
    char gmc[20];
    int a,b;
    float fsf,xf,yf,zf,ef;
    for(a=0;gm[a]!='\0';a++){
        gmc[a]=gm[a+1];
    }
    int gmi=atoi(gmc);
    float fsf=atof(fs),
            xf=atof(x),
            yf=atof(y),
            zf=atof(z),
            ef=atof(e);
    switch(gm[0]){
    case 'G'://8
    switch(gmi){
        case 0:g0(fsf,xf,yf,zf,ef);break;
        case 1:g0(fsf,xf,yf,zf,ef);break;
//F：喷嘴最大移动速度,mm/min
//X、Y、Z：命令喷嘴移动到给定坐标值处,mm
//E：控制给丝量,mm
        case 5:break;//B样条
        case 21:break;
//G20 - 使用英寸作为长度单位。
//G21 - 使用毫米表示长度单位。
        case 28:g28(xf,yf,zf);break;
//复位
        case 90:g90();break;
        case 91:g91();break;
//G90命令打印机使用绝对坐标系，G91命令打印机使用相对坐标系
        case 92:g92(xf,yf,zf,ef);break;
//G92是重新声明当前位置是什么数值
        }break;//G

    case 'M'://13
    switch(gmi){
        case 82:m82();break;
        case 83:m83();break;
//M82命令使用绝对挤出模式，M83命令相对挤出模式
        case 84:m84();break;
//M84:禁用所有步进器或设置超时
//M85:设置不活动步进器关闭超时
        case 104:m104(fsf);break;
        case 109:m109(fsf);break;
//M104是不等待喷嘴加热到给定温度，M109是等待喷嘴加热到给定温度后才开始执行下一条命令。S，单位是摄氏度
        case 105:m105();break;
//M105：报告当前温度
        case 106:m106(fsf);break;
//控制打印机'的冷却风扇运作，S，代表风扇运行功率，范围为0~255，0为不运作，255为100%功率。
        case 107:m106(0);break;
//关闭风扇
        case 117:break;
//LCD消息文本
        case 140:m140(fsf);break;
        case 190:m190(fsf);break;
//M140是命令热床加热到给定温度,M190是等待热床加热到给定温度温度参数S，单位为摄氏度。
        case 204:m204(fsf);break;
//M204 - 设置默认加速度单位为mm / sec ^ 2
        case 205:m205(xf,yf,zf,ef);break;
//M205 - 设置高级设置。 现行单位适用：
//S <打印移动> T <移动>最小速度
//B <最小段时间>
//X ，Y ，Z ，E 最大跳动速度(急拉)
        case 300:m300();
//播放音
        }//M
    }//gm
}

void g0(float fsf,float xf,float yf,float zf,float ef){
    
}

void g28(float  xf,float  yf,float  zf){
    
}

void g90(){
    
}

void g91(){
    
}

void g92(){
    
}

void m82(){
    
}

void m83(){
    
}

void m84(){
    
}

void m104(float  fsf){
    
}

void m105(){
    
}

void m106(float fsf){
    
}

void m109(float fsf){
    
}

void m140(float fsf){
    
}

void m190(float fsf){
    
}

void m204(float fsf){
    
}

void m205(float xf,float yf,float zf,float ef){
    
}

void m300(float fsf){
    
}

