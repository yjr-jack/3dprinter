#include <stdio.h>
#include <stdlib.h>
#include "divide.h"

void main(){
    get();
}