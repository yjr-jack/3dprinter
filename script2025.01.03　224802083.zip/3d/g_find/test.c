#include <stdio.h>
#include <stdlib.h>
void main(){
    char a[50]="abc";
    
    int b;
    
    switch(a[0]){
        case 'a':printf("1");
    }
}