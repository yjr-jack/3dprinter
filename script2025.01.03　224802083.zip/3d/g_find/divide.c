int gl=0,ml=0,al=0,gl2[100],ml2[100];

void get(){
    FILE *fp;
    char str[100];
    int a;
    if( (fp=fopen("/var/mobile/Containers/Data/Application/4FF6791B-136C-4F0E-AD2F-0AF648E44C8A/Documents/KeepData/script/3d/g_find/3d2.txt","rt")) == NULL ){
        puts("Fail to open file!");
        exit(1);
    }
   
    while(fgets(str, 99, fp) != NULL){
        if(str[0]!='\n'&&str[0]!=';'&&str[0]!='\0'){
            divide(str);
        }
    }fclose(fp);
    
    printf("gl:%d\nml:%d\nal:%d\ngl2:\n",gl,ml,al);
    for(a=0;a<gl;a++){
        printf("%d ",gl2[a]);
    }
    printf("ml2:\n");
    for(a=0;a<ml;a++){
        printf("%d ",ml2[a]);
        
    }
}

int find_gl(int a){
    int c;
    for(c=0;c<gl;c++){
        if(gl2[c]==a) return 1;
    }
    return -1;
}

int find_ml(int a){
    int c;
    for(c=0;c<ml;c++){
        if(ml2[c]==a) return 1;
    }
    return -1;
}

void divide(char str[]){
    
    int a,gm;
    char str2[20]="\0",str3[20]="\0";
    
    for(a=0;(str[a]!='\n'&&str[a]!=';'&&str[a]!='\0'&&str[a]!=' ');a++){
        str2[a]=str[a];
    }
    str2[a]='\0';
    for(a=1;a<20;a++){
        str3[a-1]=str2[a];
    }
    gm=atoi(str3);
    a=0;
    switch(str2[0]){
    case 'G':
    if(find_gl(gm)==-1){
        gl2[gl]=gm;
        gl++;
    }
    /*
    if(str2[1]=='5'){
        printf(str);
    }
    */
    break;
    case 'M':
    if(find_ml(gm)==-1){
        ml2[ml]=gm;
        ml++;
    }
    /*
if(str2[1]=='2'&&str2[2]=='0'&&str2[3]=='5'){
        printf(str);
    }
    */
    break;
    default:
    printf("default\n");
    al++;
    }
}