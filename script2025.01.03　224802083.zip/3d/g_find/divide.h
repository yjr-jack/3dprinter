#include <stdio.h>
#include <stdlib.h>
void get();
void divide(char str[]);
int find_gl(int a);
int find_ml(int a);