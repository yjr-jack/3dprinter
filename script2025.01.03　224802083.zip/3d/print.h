#include <stdio.h>
#include <stdlib.h>
void print(char gm[],char fs[],char x[],char y[],char z[],char e[]);
void g0(float fsf,float xf,float yf,float zf,float ef);
void g28(float  xf,float  yf,float  zf);
void g90();
void g91();
void g92();
void m82();
void m83();
void m84();
void m104(float  fsf);
void m105();
void m106(float fsf);
void m109(float fsf);
void m140(float fsf);
void m190(float fsf);
void m204(float fsf);
void m205(float xf,float yf,float zf,float ef);
void m300(float fsf);
